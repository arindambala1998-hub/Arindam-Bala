import 'package:flutter/material.dart';

import '../../../services/business_api.dart';
import '../controllers/business_profile_controller.dart';

class BPPostsTab extends StatelessWidget {
  final BusinessProfileController ctrl;

  const BPPostsTab({super.key, required this.ctrl});

  String? _extractImage(Map p) {
    final keys = [
      "image",
      "image_url",
      "thumbnail",
      "media",
      "post_image",
      "video_thumb",
    ];

    for (final key in keys) {
      final v = (p[key] ?? '').toString().trim();
      if (v.isNotEmpty) return BusinessAPI.toPublicUrl(v);
    }

    final imgs = p["images"];
    if (imgs is List && imgs.isNotEmpty) {
      final v = (imgs.first ?? '').toString().trim();
      if (v.isNotEmpty) return BusinessAPI.toPublicUrl(v);
    }

    final mediaUrls = p['media_urls'];
    if (mediaUrls is List && mediaUrls.isNotEmpty) {
      final v = (mediaUrls.first ?? '').toString().trim();
      if (v.isNotEmpty) return BusinessAPI.toPublicUrl(v);
    }

    return null;
  }

  @override
  Widget build(BuildContext context) {
    final pager = ctrl.postsPager;

    if (pager.loadingFirst && pager.items.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }

    if (pager.error.isNotEmpty && pager.items.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(pager.error, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () => pager.loadFirst(),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () async => ctrl.refresh(),
      child: NotificationListener<ScrollNotification>(
        onNotification: (n) {
          if (n.metrics.pixels >= n.metrics.maxScrollExtent - 220) {
            pager.loadNext();
          }
          return false;
        },
        child: pager.items.isEmpty
            ? const Center(
                child: Text(
                  "No posts yet",
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                ),
              )
            : GridView.builder(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(1),
                itemCount: pager.items.length + (pager.hasMore ? 1 : 0),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  mainAxisSpacing: 1,
                  crossAxisSpacing: 1,
                  childAspectRatio: 1,
                ),
                itemBuilder: (_, index) {
                  if (index >= pager.items.length) {
                    return Center(
                      child: pager.loadingNext
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : IconButton(
                              onPressed: () => pager.loadNext(),
                              icon: const Icon(Icons.expand_more),
                            ),
                    );
                  }

                  final post = pager.items[index];
                  final imageUrl = _extractImage(post);

                  return GestureDetector(
                    onTap: () {
                      // TODO: open post detail when available
                    },
                    child: Container(
                      color: Colors.black12,
                      child: imageUrl != null
                          ? Image.network(
                              imageUrl,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Center(
                                child: Icon(Icons.broken_image,
                                    size: 36, color: Colors.white70),
                              ),
                            )
                          : const Center(
                              child: Icon(
                                Icons.photo,
                                size: 40,
                                color: Colors.white70,
                              ),
                            ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
